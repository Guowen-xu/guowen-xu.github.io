---
layout: archive
title: "Awards"
permalink: /awards/
author_profile: true
---


1. **RSB Postdoctoral Fellow**, NTU, July 2019

   Research Scholarship Block Postdoctoral Fellow (RSB-PDF) provides awardees with the opportunity to advance their postdoctoral training under established faculty members and build their research career. I was one of the 25 recipients of the highly competitive RSB-Postdoctoral Fellowship, who were selected from nominations from across NTU.
