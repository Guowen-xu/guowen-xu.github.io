---
title: "A distributed method to avoid higher-order deadlocks in multi-robot systems"
collection: publications
permalink: /publication/automatica-20
excerpt: ''
date: 2020-02-01
venue: 'Automatica'
paperurl: 'https://www.sciencedirect.com/science/article/pii/S0005109819305692'
citation: 'Yuan, Zhou. (2020). &quot;Paper Title Number 2.&quot; <i>Journal 1</i>. 1(2).'
---

Recommended citation: Your Name, You. (2010). "Paper Title Number 2." <i>Journal 1</i>. 1(2).
